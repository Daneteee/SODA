kubectl delete -f frontend.yaml
kubectl delete -f ingress.yaml

kubectl apply -f .
